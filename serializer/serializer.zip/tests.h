#ifndef TESTS_H
#define TESTS_H

int run_tests(int argc, char *argv[]);

#endif // TESTS_H
