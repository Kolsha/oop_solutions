#include "tests.h"


int main(int argc, char *argv[])
{
    return run_tests(argc, argv);
}
