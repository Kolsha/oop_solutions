#include "swbclient.h"

SWBClient::SWBClient(QObject *parent) :
    QTcpSocket(parent)
{
    connect(this, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

void SWBClient::onReadyRead()
{
    QByteArray msg = this->readAll();
    emit newCmd(msg);
}
