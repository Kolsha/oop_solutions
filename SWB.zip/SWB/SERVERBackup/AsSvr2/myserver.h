#pragma once
#include <QTcpServer>
#include <QAbstractSocket>
#include <QDebug>
#include "swbclient.h"

class MyServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit MyServer(QObject *parent = 0);
    void StartServer();

protected:
    QVector<SWBClient*> clients;
    void incomingConnection(qintptr handle);
    void sendBroadcastDatagram(const SWBClient *from, const QByteArray &msg);
public slots:
    void onClientDisconnected();
    void onNewCmd(const QByteArray &msg);
    
};
