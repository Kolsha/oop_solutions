#pragma once
#include <QObject>
#include <QTcpSocket>
#include <QDebug>


class SWBClient : public QTcpSocket
{
    Q_OBJECT
public:
    explicit SWBClient(QObject *parent = 0);

signals:
    void newCmd(const QByteArray &msg);
public slots:
    void onReadyRead();
};

