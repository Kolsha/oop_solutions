#include "myserver.h"

MyServer::MyServer(QObject *parent) :
    QTcpServer(parent)
{
}

void MyServer::StartServer()
{
    if(listen(QHostAddress::Any, 1234))
    {
        qDebug() << "Server: started";
    }
    else
    {
        qDebug() << "Server: not started!";
    }
}

void MyServer::incomingConnection(qintptr handle)
{
    qDebug() << "Server: incomingConnection";
    SWBClient *client = new SWBClient(this);
    if(client == nullptr){
        return ;
    }
    client->setSocketDescriptor(handle);
    clients.push_back(client);

    connect(client, SIGNAL(newCmd(QByteArray)), this, SLOT(onNewCmd(QByteArray)));
    connect(client, SIGNAL(disconnected()), this, SLOT(onClientDisconnected()));
}

void MyServer::sendBroadcastDatagram(const SWBClient *from, const QByteArray &msg)
{
    qDebug() << "Broadcast: " << msg;
    for(auto it = clients.begin(); it != clients.end(); it++){
        SWBClient *client = *it;
        if(client == from){
            continue;
        }
        client->write(msg);
    }

}

void MyServer::onClientDisconnected()
{
    /// may be notify other
    SWBClient *client = qobject_cast<SWBClient *>(QObject::sender());
    if(client == nullptr){
        return ;
    }

    qDebug() << "Disconnected: " << client->socketDescriptor() ;
    int idx = clients.indexOf(client);
    if(idx >= 0){
        clients.remove(idx);
    }
}

void MyServer::onNewCmd(const QByteArray &msg)
{
    SWBClient *client = qobject_cast<SWBClient *>(QObject::sender());
    if(client == nullptr){
        return ;
    }
    qDebug() << "New cmd from: " << client->socketDescriptor();
    qDebug() << msg ;

    int tmp = rand() % 5;
    if(tmp < 2){
        sendBroadcastDatagram(client, msg);
    }
}
