#pragma once

#include "datamodel.h"
#include "sys_cmd.h"
#include "draw_cmd.h"


namespace SWB {


static const  uint32_t cmdVersion = 1;

class VariantinatorBase {
public:
    VariantinatorBase() {}
    virtual ~VariantinatorBase() {}
    virtual std::shared_ptr<BaseCMD> create(const QByteArray &bytes) = 0;
};

template< class T>
class Variantinator : public VariantinatorBase {
public:
    Variantinator() {}
    virtual ~Variantinator() {}
    virtual std::shared_ptr<BaseCMD> create(const QByteArray &bytes);
};


class CMDFactory
{
private:
    using TSwitchToVariant =  std::unordered_map<uint32_t, std::shared_ptr<VariantinatorBase> > ;
    TSwitchToVariant m_switchToVariant;
public:
    CMDFactory();
    std::shared_ptr<BaseCMD> create(const QByteArray &bytes);
    QByteArray serialize(const BaseCMD* obj);
};



}
