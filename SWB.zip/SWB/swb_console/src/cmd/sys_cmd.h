#pragma once

#include "datamodel.h"




namespace SWB {


class SayHello : public SysCMD{
public:
    SayHello(){}
    SayHello(const QByteArray &) { ready_to_execute = true; }
    void execute(QObject *obj){
        if(!this->checkIncomingObject(obj)){
            return ;
        }
    }
    QByteArray getSerialized() const;
    ADD_UNIQUE_ID
};

//class ClientCountUpd : public SysCMD{
//public:
//    uint32_t count = 0;
//    ClientCountUpd(uint32_t _count);
//    ClientCountUpd(const QByteArray &bytes);
//    void execute(QObject *obj);
//    QByteArray getSerialized() const;
//    ADD_UNIQUE_ID
//};




}
