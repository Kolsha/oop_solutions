#include "sys_cmd.h"

namespace SWB {



QByteArray SayHello::getSerialized() const
{
    QByteArray res("Hi, asshole;-)");
    return std::move(res);
}


}
