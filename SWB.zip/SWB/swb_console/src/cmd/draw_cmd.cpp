#include "draw_cmd.h"
#include "datamodel.h"



namespace SWB {



namespace{

#define DESERIALIZE(CODE) \
    try{ \
    QDataStream stream(bytes); \
    stream >> CODE; \
    ready_to_execute = true; \
} \
    catch(...){ \
    ready_to_execute = false; \
} \

#define SERIALIZE(CODE) \
    QByteArray res;\
    QDataStream stream(&res, QIODevice::WriteOnly);\
    stream << CODE; \
    return std::move(res); \

}




DrawAllCanvas::DrawAllCanvas(const QPixmap &other) :
    canvas(other)
{
    ready_to_execute = true;
}

DrawAllCanvas::DrawAllCanvas(const QByteArray &bytes)
{
    DESERIALIZE(canvas);
}

void DrawAllCanvas::execute(QObject *obj)
{
    if(!this->checkIncomingObject(obj) || !ready_to_execute){
        return ;
    }
    data->getData()->operator =(canvas);

}

QByteArray DrawAllCanvas::getSerialized() const
{
    SERIALIZE(canvas);
}














DrawPoint::DrawPoint(const QPoint &_point, const QColor &_color):
    point(_point), color(_color)
{
    ready_to_execute = true;
}

DrawPoint::DrawPoint(const QByteArray &bytes)
{
    DESERIALIZE(point >> color);
}

void DrawPoint::execute(QObject *obj)
{
    if(!this->checkIncomingObject(obj) || !ready_to_execute){
        return ;
    }
    QPainter painter(data->getData().get());
    QPen pen(color, 2);
    painter.setPen(pen);
    painter.drawPoint(point);
}

QByteArray DrawPoint::getSerialized() const
{
    SERIALIZE(point << color);
}









DrawText::DrawText(const QPoint &_point, const QColor &_color, const QFont &_font, const QString &_str):
    point(_point), color(_color), font(_font), str(_str)
{
    ready_to_execute = true;
}

DrawText::DrawText(const QByteArray &bytes)
{
    DESERIALIZE(point >> color >> font >> str);
}

void DrawText::execute(QObject *obj)
{
    if(!this->checkIncomingObject(obj) || !ready_to_execute){
        return ;
    }
    QPainter painter(data->getData().get());
    QPen pen(color, 2);
    painter.setPen(pen);
    painter.setFont(font);
    painter.drawText(point, str);
}

QByteArray DrawText::getSerialized() const
{
    SERIALIZE(point << color << font << str);
}




}
