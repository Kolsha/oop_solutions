#include <QByteArray>
#include <QDataStream>
#include "cmd_factory.h"

namespace SWB {

namespace {
#define REGISTER_CMD(CMD) \
    m_switchToVariant.insert({CMD::getUniqueIdStatic(), \
    std::shared_ptr<VariantinatorBase>( new Variantinator<CMD>) });
}


CMDFactory::CMDFactory()
{
    REGISTER_CMD(SayHello);
    REGISTER_CMD(DrawPoint);
    REGISTER_CMD(DrawAllCanvas);
    REGISTER_CMD(DrawText);
}

std::shared_ptr<BaseCMD> CMDFactory::create(const QByteArray &bytes)
{
    QDataStream stream(bytes);
    uint32_t _ver, id;
    QByteArray tmp;
    stream >> _ver >> id >> tmp;
    if(_ver != cmdVersion){
        return nullptr;
    }
    auto it = m_switchToVariant.find(id);
    if(it == m_switchToVariant.end()){
        return nullptr;
    }
    return it->second->create(tmp);
}

QByteArray CMDFactory::serialize(const BaseCMD *obj)
{
    QByteArray res;


    auto it = m_switchToVariant.find( obj->getUniqueId() );
    if( it != m_switchToVariant.end() ){
        QDataStream stream(&res, QIODevice::WriteOnly);
        stream << cmdVersion;
        stream << obj->getUniqueId();
        stream << obj->getSerialized();
    }

    return std::move(res);
}

template<class T>
std::shared_ptr<BaseCMD> Variantinator<T>::create(const QByteArray &bytes)
{
    return std::shared_ptr<BaseCMD>(new T(std::move(bytes)));
}

}
