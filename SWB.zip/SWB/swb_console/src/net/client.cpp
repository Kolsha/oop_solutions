#include "client.h"

namespace SWB {



Client::Client(QObject *parent) :
    QTcpSocket(parent)
{
    connect(this, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

void Client::onReadyRead()
{
    QByteArray msg = this->readAll();
    emit newCmd(msg);
}


}
