#pragma once
#include <QObject>
#include <QTcpSocket>
#include <QDebug>

namespace SWB {



class Client : public QTcpSocket
{
    Q_OBJECT
public:
    explicit Client(QObject *parent = 0);

signals:
    void newCmd(const QByteArray &msg);
private slots:
    void onReadyRead();
};

}
