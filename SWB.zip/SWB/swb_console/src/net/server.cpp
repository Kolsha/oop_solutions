#include "server.h"

namespace SWB {



Server::Server(QObject *parent) :
    QTcpServer(parent)
{
}

bool Server::start()
{
    if(listen(QHostAddress::Any, 1234))
    {
        qDebug() << "Server: started";
        return true;
    }
    else
    {
        qDebug() << "Server: not started!";
    }

    return false;

}

void Server::incomingConnection(qintptr handle)
{
    qDebug() << "Server: incomingConnection";
    Client *client = new Client(this);
    if(client == nullptr){
        return ;
    }
    client->setSocketDescriptor(handle);
    clients.push_back(client);

    connect(client, SIGNAL(newCmd(QByteArray)), this, SLOT(onNewCmd(QByteArray)));
    connect(client, SIGNAL(disconnected()), this, SLOT(onClientDisconnected()));
}

void Server::sendBroadcastDatagram(const Client *from, const QByteArray &msg)
{
    qDebug() << "Broadcast: " << msg;
    for(auto it = clients.begin(); it != clients.end(); it++){
        Client *client = *it;
        if(client == from){
            continue;
        }
        client->write(msg);
    }

}

void Server::onClientDisconnected()
{
    /// may be notify other
    Client *client = qobject_cast<Client *>(QObject::sender());
    if(client == nullptr){
        return ;
    }

    qDebug() << "Disconnected: " << client->socketDescriptor() ;
    int idx = clients.indexOf(client);
    if(idx >= 0){
        clients.remove(idx);
    }
}

void Server::onNewCmd(const QByteArray &msg)
{
    Client *client = qobject_cast<Client *>(QObject::sender());
    if(client == nullptr){
        return ;
    }
    qDebug() << "New cmd from: " << client->socketDescriptor();
    qDebug() << msg ;
    /*std::shared_ptr<BaseCMD> cmd = factory.create(msg);
    cmd->execute(&data);
    l.setPixmap(*data.getData());
    l.show();*/
    emit newCmd(client, msg);

}


}
