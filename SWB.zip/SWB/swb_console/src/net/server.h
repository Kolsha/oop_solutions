#pragma once
#include <QTcpServer>
#include <QAbstractSocket>
#include <QDebug>


#include <QtCore>
#include <QtGui>
#include <QApplication>
#include <QLabel>

#include "cmd_factory.h"
#include "client.h"

namespace SWB {


class Server : public QTcpServer
{
    Q_OBJECT
public:
    explicit Server(QObject *parent = 0);
    bool start();
protected:
    QVector<Client*> clients;
    void incomingConnection(qintptr handle);
    void sendBroadcastDatagram(const SWB::Client *from, const QByteArray &msg);
private slots:
    void onClientDisconnected();
    void onNewCmd(const QByteArray &msg);
signals:
    ///void newCmd(std::shared_ptr<BaseCMD> cmd);

    void newCmd(SWB::Client *from, const QByteArray &msg);
    void clientDisconnected();
    
};


}
