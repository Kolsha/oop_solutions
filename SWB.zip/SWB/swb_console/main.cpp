#include <QCoreApplication>
#include <QTime>
#include <QtCore>
#include <QtGui>
#include "server_app.h"

#include "client.h"


void onNewCmd(const QByteArray &msg){
    qDebug() <<  "Readed from server1: " << msg;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    ServerApp app;

    using namespace SWB;
    Client client;
    QObject::connect(&client, &Client::newCmd, onNewCmd);
    CMDFactory factory;

    client.connectToHost("localhost", 1234);

    if(client.waitForConnected(3000))
    {
        qDebug() << "Connected!";

        QColor clr(rand() % 255, rand() % 255, rand() % 255 );
        for(;;){

            SWB::DrawText dt(QPoint(rand() % 800, rand() % 600), clr, QFont("", 10), "Test");
            //SayHello dt;
            QByteArray msg = factory.serialize(&dt);
            client.write(msg);
            if(!client.waitForBytesWritten(1000)){
                break;
            }
            qDebug() << "Readed from server: " << client.readAll();
            QTime dieTime = QTime::currentTime().addMSecs(5000);
            while (QTime::currentTime() < dieTime)
                QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
        }

        client.close();
    }
    else
    {
        qDebug() << "Not connected!";
    }



    return a.exec();
}
