#pragma once
#include <QTcpServer>
#include <QAbstractSocket>
#include <QDebug>


#include <QtCore>
#include <QtGui>
#include <QApplication>
#include <QLabel>

#include "cmd_factory.h"
#include "server.h"


class ServerApp : public QObject
{
    Q_OBJECT
private:
    QLabel display;
    SWB::DataModel data;
    SWB::Server server;
    SWB::CMDFactory factory;
private slots:
    void onNewCmd(SWB::Client *from, const QByteArray &msg);
    void onClientDisconnected();
public:
    explicit ServerApp(QObject *parent = 0);
};
