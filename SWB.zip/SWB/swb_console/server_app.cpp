#include <QTcpServer>
#include <QAbstractSocket>
#include <QDebug>


#include <QtCore>
#include <QtGui>
#include <QApplication>
#include <QLabel>
#include "server_app.h"


QString GetRandomString()
{
    const QString possibleCharacters("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
    const int randomStringLength = 12; // assuming you want random strings of 12 characters

    QString randomString;
    for(int i=0; i<randomStringLength; ++i)
    {
        int index = qrand() % possibleCharacters.length();
        QChar nextChar = possibleCharacters.at(index);
        randomString.append(nextChar);
    }
    return randomString;
}



void ServerApp::onNewCmd(SWB::Client *from, const QByteArray &msg)
{
    std::shared_ptr<SWB::BaseCMD> cmd = factory.create(msg);
    if(cmd == nullptr){
        //send err
        return ;
    }


    if(dynamic_cast<SWB::SysCMD*>(cmd.get())){

        if(cmd->getUniqueId() == SWB::SayHello::getUniqueIdStatic())
        {
            QPixmap &canvas = *(data.getData());
            SWB::DrawAllCanvas dac(canvas);
            QByteArray answer = factory.serialize(&dac);
            from->write(answer);
        }


    }else{
        cmd->execute(&data);
        display.setPixmap(*(data.getData()));
        display.show();
    }


}

void ServerApp::onClientDisconnected()
{

}

ServerApp::ServerApp(QObject *parent) : QObject(parent)
{
    srand(time(NULL));

    if(!server.start()){
        qDebug() << "Faild start server";
        return ;

    }

    connect(&server, SIGNAL(newCmd(SWB::Client*,QByteArray)), this, SLOT(onNewCmd(SWB::Client*,QByteArray)));
    connect(&server, SIGNAL(clientDisconnected()), this, SLOT(onClientDisconnected()));

}
