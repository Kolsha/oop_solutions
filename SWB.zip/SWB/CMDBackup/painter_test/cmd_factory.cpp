#include <QByteArray>
#include <QDataStream>
#include "cmd_factory.h"


SWB::CMDFactory::CMDFactory()
{
    REGISTER_CMD(SayHello);
    REGISTER_CMD(DrawPoint);
}

std::shared_ptr<SWB::BaseCMD> SWB::CMDFactory::create(const QByteArray &bytes)
{
    QDataStream stream(bytes);
    uint32_t _ver, id;
    QByteArray tmp;
    stream >> _ver >> id >> tmp;
    if(_ver != cmdVersion){
        return nullptr;
    }
    auto it = m_switchToVariant.find(id);
    if(it == m_switchToVariant.end()){
        return nullptr;
    }
    return it->second->create(tmp);
}

QByteArray SWB::CMDFactory::serialize(const SWB::BaseCMD *obj)
{
    QByteArray res;


    auto it = m_switchToVariant.find( obj->getUniqueId() );
    if( it != m_switchToVariant.end() ){
        QDataStream stream(&res, QIODevice::WriteOnly);
        stream << cmdVersion;
        stream << obj->getUniqueId();
        stream << obj->getSerialized();
    }

    return std::move(res);
}
