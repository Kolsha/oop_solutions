#ifndef TEST_CREATOR_H
#define TEST_CREATOR_H

#include <iostream>
#include <memory>
#include <vector>
#include <QByteArray>
#include <unordered_map>

static const  size_t cmdVersion = 1;

#define ADD_UNIQUE_ID \
    public: \
    static size_t getUniqueIdStatic(){\
    return reinterpret_cast<size_t>(&getUniqueIdStatic); } \
    \
    virtual size_t getUniqueId() const {\
    return getUniqueIdStatic();};\


class MyBase
{

public:

    MyBase() { }
    virtual void run() = 0;
    ADD_UNIQUE_ID
};





class VariantA : public MyBase
{

public:
    VariantA (const QByteArray &bytes) { }
    virtual void run()
    {
        // Run code specific to hardware Variant-A
    }
    ADD_UNIQUE_ID
};


class VariantB : public MyBase
{
public:
    VariantB (const QByteArray &bytes) { }
    virtual void run()
    {
        // Run code specific to hardware Variant-B
    }
    ADD_UNIQUE_ID
};




class VariantinatorBase {
public:
    VariantinatorBase() {}
    virtual ~VariantinatorBase() {}
    virtual std::shared_ptr<MyBase> Create(const QByteArray &bytes) = 0;
};

template< class T >
class Variantinator : public VariantinatorBase {
public:
    Variantinator() {}
    virtual ~Variantinator() {}
    virtual std::shared_ptr<MyBase> Create(const QByteArray &bytes) {
        return std::shared_ptr<MyBase>(new T(bytes));
    }
};


class VariantFactory
{
public:
    VariantFactory()
    {

        // put cmd here

        m_switchToVariant.insert({VariantA::getUniqueIdStatic(),
                                  std::shared_ptr<VariantinatorBase>( new Variantinator<VariantA>) });
        m_switchToVariant.insert({VariantB::getUniqueIdStatic(),
                                  std::shared_ptr<VariantinatorBase>( new Variantinator<VariantB>) });
    }

    std::shared_ptr<MyBase> Create( size_t type )
    {
        auto it = m_switchToVariant.find( type );
        if( it == m_switchToVariant.end() ) return nullptr;
        return it->second->Create("");
    }
    QByteArray serialize(const MyBase* obj){
        QByteArray res;
        auto it = m_switchToVariant.find( obj->getUniqueId() );
        if( it != m_switchToVariant.end() ){

        }

        return std::move(res);
    }

private:
    using TSwitchToVariant =  std::unordered_map<size_t, std::shared_ptr<VariantinatorBase> > ;
    TSwitchToVariant m_switchToVariant;
};














#endif // TEST_CREATOR_H
