#pragma once

#include <QObject>
#include <QPixmap>
#include <QDebug>
#include <iostream>
#include <memory>
#include <unordered_map>

namespace SWB {





#define ADD_UNIQUE_ID \
    public: \
    static uint32_t getUniqueIdStatic(){\
    size_t s_id = reinterpret_cast<size_t>(&getUniqueIdStatic);\
    uint32_t id = static_cast<uint32_t>(s_id);\
    return  id;} \
    \
    virtual uint32_t getUniqueId() const {\
    return getUniqueIdStatic();};\





class DataModel : public QObject
{
    Q_OBJECT
private:
    std::shared_ptr<QPixmap> canvas;
    void setDefaultCanvas();
public:
    explicit DataModel(QObject *parent = 0);
    DataModel(const QString &filename);
    DataModel(const QSize &size, const QColor &background = Qt::white);
    std::shared_ptr<QPixmap> getData(){
        return canvas;
    }

    virtual ~DataModel(){

    }

signals:

public slots:
};


class BaseCMD {
protected:
    bool ready_to_execute = false;
public:
    virtual void execute(QObject *obj) = 0;
    virtual QByteArray getSerialized() const = 0;
    virtual ~BaseCMD(){}
    ADD_UNIQUE_ID
};


class NullCmd : public BaseCMD{
    void execute(QObject *){
        return ;
    }

    QByteArray getSerialized() const{
        return std::move(QByteArray(""));
    }
    ADD_UNIQUE_ID
};


class DrawCMD : public BaseCMD{
protected:
    DataModel* data = nullptr;
    bool checkIncomingObject(QObject *obj){
        data = dynamic_cast<DataModel*>(obj);
        return (data != nullptr);
    }

public:
    virtual void execute(QObject *obj) = 0;
    virtual QByteArray getSerialized() const = 0;
    virtual ~DrawCMD(){}
    ADD_UNIQUE_ID
};

class SysCMD : public BaseCMD{
protected:
    DataModel* server = nullptr;
    bool checkIncomingObject(QObject *obj){
        server = dynamic_cast<DataModel*>(obj);
        return (server != nullptr);
    }
public:
    virtual void execute(QObject *obj) = 0;
    virtual QByteArray getSerialized() const = 0;
    virtual ~SysCMD(){}
    ADD_UNIQUE_ID
};













}


