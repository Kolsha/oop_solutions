#include "draw_cmd.h"
#include "datamodel.h"

namespace{

#define DESERIALIZE(CODE) \
    try{ \
    QDataStream stream(bytes); \
    stream >> CODE; \
    ready_to_execute = true; \
} \
    catch(...){ \
    ready_to_execute = false; \
} \

#define SERIALIZE(CODE) \
    QByteArray res;\
    QDataStream stream(&res, QIODevice::WriteOnly);\
    stream << CODE; \
    return std::move(res); \

}




SWB::DrawAllCanvas::DrawAllCanvas(const QPixmap &other) :
    canvas(other)
{
    ready_to_execute = true;
}

SWB::DrawAllCanvas::DrawAllCanvas(const QByteArray &bytes)
{
    DESERIALIZE(canvas);
}

void SWB::DrawAllCanvas::execute(QObject *obj)
{
    if(!this->checkIncomingObject(obj) || !ready_to_execute){
        return ;
    }
    data->getData()->operator =(canvas);

}

QByteArray SWB::DrawAllCanvas::getSerialized() const
{
    SERIALIZE(canvas);
}














SWB::DrawPoint::DrawPoint(const QPoint &_point, const QColor &_color):
    point(_point), color(_color)
{
    ready_to_execute = true;
}

SWB::DrawPoint::DrawPoint(const QByteArray &bytes)
{
    DESERIALIZE(point >> color);
}

void SWB::DrawPoint::execute(QObject *obj)
{
    if(!this->checkIncomingObject(obj) || !ready_to_execute){
        return ;
    }
    QPainter painter(data->getData().get());
    QPen pen(color, 2);
    painter.setPen(pen);
    painter.drawPoint(point);
}

QByteArray SWB::DrawPoint::getSerialized() const
{
    SERIALIZE(point << color);
}









SWB::DrawText::DrawText(const QPoint &_point, const QColor &_color, const QFont &_font, const QString &_str):
    point(_point), color(_color), font(_font), str(_str)
{
    ready_to_execute = true;
}

SWB::DrawText::DrawText(const QByteArray &bytes)
{
    DESERIALIZE(point >> color >> font >> str);
}

void SWB::DrawText::execute(QObject *obj)
{
    if(!this->checkIncomingObject(obj) || !ready_to_execute){
        return ;
    }
    QPainter painter(data->getData().get());
    QPen pen(color, 2);
    painter.setPen(pen);
    painter.setFont(font);
    painter.drawText(point, str);
}

QByteArray SWB::DrawText::getSerialized() const
{
    SERIALIZE(point << color << font << str);
}
