#pragma once

#include "datamodel.h"




namespace SWB {


class SayHello : public SysCMD{
public:
    SayHello(const QByteArray &) { }
    void execute(QObject *obj){
        if(!this->checkIncomingObject(obj)){
            return ;
        }
    }
    QByteArray getSerialized() const;
    ADD_UNIQUE_ID
};




}
