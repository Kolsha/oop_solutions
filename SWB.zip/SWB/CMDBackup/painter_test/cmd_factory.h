#pragma once

#include "datamodel.h"
#include "sys_cmd.h"
#include "draw_cmd.h"


namespace SWB {


static const  uint32_t cmdVersion = 1;


#define REGISTER_CMD(CMD) \
    m_switchToVariant.insert({CMD::getUniqueIdStatic(), \
    std::shared_ptr<VariantinatorBase>( new Variantinator<CMD>) });




class VariantinatorBase {
public:
    VariantinatorBase() {}
    virtual ~VariantinatorBase() {}
    virtual std::shared_ptr<BaseCMD> create(const QByteArray &bytes) = 0;
};

template< class T>
class Variantinator : public VariantinatorBase {
public:
    Variantinator() {}
    virtual ~Variantinator() {}
    virtual std::shared_ptr<BaseCMD> create(const QByteArray &bytes) {
        return std::shared_ptr<BaseCMD>(new T(std::move(bytes)));
    }
};


class CMDFactory
{
private:
    using TSwitchToVariant =  std::unordered_map<uint32_t, std::shared_ptr<VariantinatorBase> > ;
    TSwitchToVariant m_switchToVariant;
public:
    CMDFactory();
    std::shared_ptr<BaseCMD> create(const QByteArray &bytes);
    QByteArray serialize(const BaseCMD* obj);
};



}
