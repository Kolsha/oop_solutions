#include <QtCore>
#include <QtGui>
#include <QApplication>
#include <QLabel>
#include <QColor>
#include <QPixmap>
#include "datamodel.h"
#include "cmd_factory.h"
#include "draw_cmd.h"

int main(int argc, char *argv[])
{
    using namespace std;
    using namespace SWB;


    /*CMDFactory factory;

    VariantinatorBase *abc = new Variantinator<DrawPoint>();
    abc->create("");
    SayHello t(""), t1("");
    DrawPoint dr("");
    std::cout <<t.getUniqueIdStatic() << endl;
    std::cout <<t1.getUniqueId() << endl;
    cout << dr.getUniqueIdStatic() << endl;
    //std::shared_ptr<BaseCMD> pt1 = factory.create(t1.getUniqueId());
    //std::shared_ptr<BaseCMD> pt2 = factory.create(DrawPoint::getUniqueIdStatic());

    //std::cout << pt1->getUniqueId() << endl;
    //std::cout << pt2->getUniqueId() << endl;
    //factory.Register(new Variantinator<VariantA>());
    //factory.Register(new Variantinator<VariantB>);
    //factory.Register( 2, new Variantinator<VariantC> );
    //std::unique_ptr<Variant> thing = factory.Create( switchValue );
    std::cout << "fsfs" << endl;

    cout << factory.serialize(&t1).toStdString() << endl;


    return 0;
    VariantA test1;
    VariantB test2, test3;
    cout << test1.getUniqueId() << endl;
    cout << test3.getUniqueId() << endl;
    cout << test2.getUniqueId() << endl;

    return 0;


    QByteArray ba;
    ba.resize(5);
    ba[0] = 1;
    ba[1] = 0xb8;
    ba[2] = 0x64;
    ba[3] = 0x18;
    ba[4] = 0xca;
*/
    QApplication a(argc, argv);

    QLabel l;

    QPixmap pixmap;
    SWB::DataModel test;

    pixmap.load(QString::fromUtf8("/home/kolsha/Изображения/1fdk_oY-J-c.jpg"));

    DrawAllCanvas dac(pixmap);
    dac.execute(&test);

    DrawPoint dp(QPoint(10, 10), Qt::blue);
    dp.execute(&test);

    QFont dtf("", 10, 10, true);
    dtf.setPointSize ( 28 );
    DrawText dt(QPoint(50, 50), Qt::blue, dtf, "Test suka");

    //dt.execute(&test);

    QByteArray dt_ser = dt.getSerialized();




    /*QPainter painter(&pixmap);
    QPen Red((QColor(255,0,0)),1);
    painter.setPen(Red);
    painter.drawLine(50,50,250,250);

    pixmap = pixmap.scaled(1000, 600);*/

    std::shared_ptr<QPixmap> tmp = test.getData();
    l.setPixmap(*tmp);
    l.show();
    DrawText dt1(dt_ser);
    dt1.execute(&test);

    l.setPixmap(*tmp);
    //l.show();

    return a.exec();
}


/*
 * https://stackoverflow.com/questions/16047560/creating-dynamic-type-in-c/16047779#16047779
 * http://oop.afti.ru/materials/115
 * http://www.qtcentre.org/threads/31871-Draw-line-on-image-using-QPainter
 * https://wiki.qt.io/Converting_QPixmap_to_QByteArray
 */
