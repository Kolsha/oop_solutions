#include "datamodel.h"

namespace SWB {


void DataModel::setDefaultCanvas()
{
    canvas = std::shared_ptr<QPixmap> (new QPixmap(800, 600));
}

DataModel::DataModel(QObject *parent) : QObject(parent)
{
    setDefaultCanvas();
}

DataModel::DataModel(const QString &filename)
{
    setDefaultCanvas();
    canvas->load(filename);
}

DataModel::DataModel(const QSize &size, const QColor &background)
{
    canvas->fill(background);
    QPixmap tmp = canvas->scaled(size);
    //todo: swap

}
}
