#pragma once

#include "datamodel.h"

#include <QPainter>

namespace SWB {



class DrawAllCanvas : public DrawCMD{
private:
    QPixmap canvas;
public:
    DrawAllCanvas(const QPixmap &other);
    DrawAllCanvas(const QByteArray &bytes);
    void execute(QObject *obj);
    QByteArray getSerialized() const;

    ADD_UNIQUE_ID
};




class DrawPoint : public DrawCMD{
private:
    QPoint point;
    QColor color;
public:
    DrawPoint(const QPoint &_point, const QColor &_color);
    DrawPoint(const QByteArray &bytes);
    void execute(QObject *obj);
    QByteArray getSerialized() const;

    ADD_UNIQUE_ID
};



class DrawText : public DrawCMD{
private:
    QPoint point;
    QColor color;
    QFont font;
    QString str;
public:
    DrawText(const QPoint &_point, const QColor &_color,
            const QFont &_font, const QString &_str);
    DrawText(const QByteArray &bytes);
    void execute(QObject *obj);
    QByteArray getSerialized() const;

    ADD_UNIQUE_ID
};







}
