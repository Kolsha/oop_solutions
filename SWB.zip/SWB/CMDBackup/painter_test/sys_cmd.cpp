#include "sys_cmd.h"



QByteArray SWB::SayHello::getSerialized() const
{
    QByteArray res("Hi, asshole;-)");
    return std::move(res);
}
