#ifndef __boy_h
#define __boy_h

#include "BaseUser/user.h"

struct Boy {
    const struct User _;
    int money;
};

extern const void *Boy;

#endif
