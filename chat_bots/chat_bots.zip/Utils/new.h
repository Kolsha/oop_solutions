#ifndef __new_h
#define __new_h

#include <stddef.h>
#include <stdarg.h>

struct Class {
    size_t size;
    void *(*ctor)(void *self, va_list *app);
    void *(*dtor)(void *self);
    void (*type_msg)(const void *self);
};

void *new(const void *class, ...);
void delete(void *item);
void type_msg(const void *self);

#endif
